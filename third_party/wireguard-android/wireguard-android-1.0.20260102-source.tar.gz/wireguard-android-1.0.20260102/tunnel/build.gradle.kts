@file:Suppress("UnstableApiUsage")

import org.gradle.api.tasks.testing.logging.TestLogEvent
import org.gradle.api.tasks.bundling.Zip

val pkg: String = providers.gradleProperty("wireguardPackageName").get()

plugins {
    alias(libs.plugins.android.library)
    `maven-publish`
    signing
}

android {
    compileSdk = 36
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    namespace = "${pkg}.tunnel"
    defaultConfig {
        minSdk = 24
    }
    externalNativeBuild {
        cmake {
            path("tools/CMakeLists.txt")
        }
    }
    testOptions.unitTests.all {
        it.testLogging { events(TestLogEvent.PASSED, TestLogEvent.SKIPPED, TestLogEvent.FAILED) }
    }
    buildTypes {
        all {
            externalNativeBuild {
                cmake {
                    targets("libwg-go.so", "libwg.so", "libwg-quick.so")
                    arguments("-DGRADLE_USER_HOME=${project.gradle.gradleUserHomeDir}")
                    arguments("-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON")
                }
            }
        }
        release {
            externalNativeBuild {
                cmake {
                    arguments("-DANDROID_PACKAGE_NAME=${pkg}")
                }
            }
        }
        debug {
            externalNativeBuild {
                cmake {
                    arguments("-DANDROID_PACKAGE_NAME=${pkg}.debug")
                }
            }
        }
    }
    lint {
        disable += "LongLogTag"
        disable += "NewApi"
    }
    publishing {
        singleVariant("release") {
            withJavadocJar()
            withSourcesJar()
        }
    }
}

dependencies {
    implementation(libs.androidx.annotation)
    implementation(libs.androidx.collection)
    compileOnly(libs.jsr305)
    testImplementation(libs.junit)
}

publishing {
    publications {
        register<MavenPublication>("release") {
            groupId = pkg
            artifactId = "tunnel"
            version = providers.gradleProperty("wireguardVersionName").get()
            afterEvaluate {
                from(components["release"])
            }
            pom {
                name = "WireGuard Tunnel Library"
                description = "Embeddable tunnel library for WireGuard for Android"
                url = "https://www.wireguard.com/"

                licenses {
                    license {
                        name = "The Apache Software License, Version 2.0"
                        url = "http://www.apache.org/licenses/LICENSE-2.0.txt"
                        distribution = "repo"
                    }
                }
                scm {
                    connection = "scm:git:https://git.zx2c4.com/wireguard-android"
                    developerConnection = "scm:git:https://git.zx2c4.com/wireguard-android"
                    url = "https://git.zx2c4.com/wireguard-android"
                }
                developers {
                    organization {
                        name = "WireGuard"
                        url = "https://www.wireguard.com/"
                    }
                    developer {
                        name = "WireGuard"
                        email = "team@wireguard.com"
                    }
                }
            }
        }
    }
    repositories {
        maven {
            name = "SonatypeUpload"
            setUrl(layout.buildDirectory.dir("sonatype"))
        }
    }
}

val releasePublication = publishing.publications.named("release").get() as MavenPublication
val mavenGroupPath = releasePublication.groupId.replace('.', '/')
val mavenArtifactId = releasePublication.artifactId
val mavenVersion = releasePublication.version

tasks.register<Zip>("zipReleasePublication") {
    dependsOn(tasks.named("publishReleasePublicationToSonatypeUploadRepository"))
    group = "distribution"
    description = "Zips the release publication in Maven repository layout."

    val sourceDir = layout.buildDirectory.dir("sonatype/${mavenGroupPath}/${mavenArtifactId}/${mavenVersion}")
    from(sourceDir)
    archiveFileName.set("${mavenArtifactId}-${mavenVersion}-maven.zip")
    destinationDirectory.set(layout.buildDirectory.dir("distributions"))
    into("${mavenGroupPath}/${mavenArtifactId}/${mavenVersion}")
}

signing {
    useGpgCmd()
    sign(publishing.publications)
}
